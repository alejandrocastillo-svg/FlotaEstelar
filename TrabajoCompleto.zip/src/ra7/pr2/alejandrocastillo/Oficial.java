/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ra7.pr2.alejandrocastillo;

/**
 *
 * @author a.castillo
 */
public class Oficial extends Tripulante {

    private int codigoIdentificacion;
    private String division;
    private double creditosGalacticos;

    public Oficial(int codigoIdentificacion, String division, double creditosGalacticos, String nombre, String apellido, String transmisor, int ciclosOrbitales) {
        super(nombre, apellido, transmisor, ciclosOrbitales);
        this.codigoIdentificacion = codigoIdentificacion;
        this.division = division;
        this.creditosGalacticos = creditosGalacticos;

    }

    //Sobrecarga
    public Oficial() {}

    public Oficial(int codigoIdentificacio, double creditosGalacticos, String nombre, String apellidos, int ciclosOrbitales) {
        super(nombre, apellidos, ciclosOrbitales);
        this.codigoIdentificacion = codigoIdentificacio;
        this.creditosGalacticos = creditosGalacticos;
    }

        @Override  //ALUMNO 1
        public void mostrarOficialCompleto() {
        String linea1 = super.toString();
            String linea2 = codigoIdentificacion + " / " + division + " / Creditos " + creditosGalacticos + " $";
            System.out.println(linea1);
            System.out.println(linea2);
        }

        @Override //ALUMNO 2
        public void mostrarOficialClasificado() {
        System.out.println(super.toString());
            System.out.println(codigoIdentificacion + " / [DIVISION CLASIFICADA] / Creditos "
                    + creditosGalacticos + " $");
        }
        
    public int getCodigoIdentificacion() {
        return codigoIdentificacion;
    }

    public void setCodigoIdentificacion(int codigoIdentificacion) {
        this.codigoIdentificacion = codigoIdentificacion;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public double getCreditosGalacticos() {
        return creditosGalacticos;
    }

    public void setCreditosGalacticos(double creditosGalacticos) {
        this.creditosGalacticos = creditosGalacticos;
    }
}
