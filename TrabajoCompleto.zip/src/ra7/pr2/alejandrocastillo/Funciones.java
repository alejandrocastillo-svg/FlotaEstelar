/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ra7.pr2.alejandrocastillo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author a.castillo
 */
public class Funciones {

    public static boolean plusPorMision(Oficial o, double plusCredito) {
        
        //Alumno 1
        if (o.getCiclosOrbitales() >= 10) {
            double plus = plusCredito;
            if (o.getDivision() != null && o.getDivision().equalsIgnoreCase("Navegacion")) {
                plus = plus * 1.5;
            }
            o.setCreditosGalacticos(o.getCreditosGalacticos() + plus);
            return true;
        }
        return false;
    }
    
    //Alumno 2
    public static boolean plusPorMision(Oficial o, double botinExploracion, double tasaReparacio) {
        if (o.getDivision() == null) return false;

        if (o.getCiclosOrbitales() >= 15 &&
                (o.getDivision().equalsIgnoreCase("Comandamiento")
                        || o.getDivision().equalsIgnoreCase("Ingenieria"))) {

            o.setCreditosGalacticos(o.getCreditosGalacticos() + botinExploracion - tasaReparacio);
            return true;
        }
        return false;
    }
    
    
    public static void ordenarPorApellido(ArrayList<Oficial> lista) {
        Collections.sort(lista, Comparator.comparing(o -> o.getApellido()));
    }
    
    // Recorrer lista y mostrar si tiene división o no
    public static void mostrarDatos(ArrayList<Oficial> lista) {
        for (Oficial o : lista) {
            if (o.getDivision() == null) {
                o.mostrarOficialClasificado();
            } else {
                o.mostrarOficialCompleto();
            }
            System.out.println();
        }
    }
}
